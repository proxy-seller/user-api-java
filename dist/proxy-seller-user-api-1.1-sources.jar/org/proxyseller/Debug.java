package org.proxyseller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Debug {

    public static void main(String[] args) throws Exception {
        try {
            Api api = new Api(new Config("yourapikey"));
            api.getConfig().setBaseUri("https://back0.proxy-seller.com/personal/api/v1/4ad2bf3127ff39e17779ef4155f9331e/");
//            System.out.println(api.ping());
//            System.out.println(api.authActive(1,"Y"));
//            System.out.println(api.residentPackage());
//            System.out.println(api.residentGeo());
            System.out.println(api.residentList());
            System.out.println(api.residentListRename(257286,"testJ"));
            System.out.println(api.residentList());
//            System.out.println(api.authList());
//            System.out.println(api.balance());
//            System.out.println(api.balancePaymentsList());
//            System.out.println(api.referenceList());
//            System.out.println(api.orderCalcIpv4(561, "2m", 5, "127.0.0.1", "OZGCNK_1", 39, 0, "Another target"));
//            System.out.println(api.balanceAdd(5.5, 29));
//            System.out.println(api.proxyList());
//            System.out.println(api.proxyCommentSet( new ArrayList<Integer>(List.of(5684878)), "text"));
//            //System.out.println(api.proxyCheck("127.0.0.1"));
//            System.out.println(api.prolongCalc("ipv4", new ArrayList<Integer>(List.of(5684878)), "1m", ""));
//            System.out.println(api.proxyDownload("ipv4","",""));
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

    }
}
